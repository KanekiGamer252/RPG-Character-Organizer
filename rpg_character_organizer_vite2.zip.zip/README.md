# RPG Character Organizer
import { useState } from "react";

// Simple React SPA for RPG Character Organizer
// Includes: list, create/edit, import/export

export default function App() {
  const [characters, setCharacters] = useState(() => {
    const saved = localStorage.getItem("rpg_characters");
    return saved ? JSON.parse(saved) : [];
  });

  const [editing, setEditing] = useState(null);

  const save = (list) => {
    setCharacters(list);
    localStorage.setItem("rpg_characters", JSON.stringify(list));
  };

  const handleSave = (char) => {
    let list;
    if (editing) {
      list = characters.map((c) => (c.id === char.id ? char : c));
    } else {
      char.id = crypto.randomUUID();
      list = [...characters, char];
    }
    save(list);
    setEditing(null);
  };

  const handleDelete = (id) => {
    const list = characters.filter((c) => c.id !== id);
    save(list);
  };

  const exportJSON = () => {
    const blob = new Blob([JSON.stringify(characters, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "personagens.json";
    a.click();
  };

  const importJSON = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target.result);
        if (Array.isArray(data)) save(data);
      } catch {}
    };
    reader.readAsText(file);
  };

  return (
    <div className="p-6 max-w-3xl mx-auto font-sans">
      <h1 className="text-3xl font-bold mb-4">RPG Character Organizer</h1>

      <div className="flex gap-3 mb-4">
        <button onClick={() => setEditing({})} className="px-4 py-2 bg-blue-600 text-white rounded">Novo Personagem</button>
        <button onClick={exportJSON} className="px-4 py-2 bg-green-600 text-white rounded">Exportar</button>
        <label className="px-4 py-2 bg-purple-600 text-white rounded cursor-pointer">
          Importar
          <input type="file" className="hidden" onChange={importJSON} />
        </label>
      </div>

      {editing ? (
        <Form character={editing} onSave={handleSave} onCancel={() => setEditing(null)} />
      ) : (
        <List characters={characters} onEdit={setEditing} onDelete={handleDelete} />
      )}
    </div>
  );
}

function List({ characters, onEdit, onDelete }) {
  if (characters.length === 0)
    return <p className="text-gray-500">Nenhum personagem registrado.</p>;

  return (
    <div className="space-y-3">
      {characters.map((c) => (
        <div key={c.id} className="border p-3 rounded shadow-sm bg-white">
          <h2 className="text-xl font-semibold">{c.name}</h2>
          <p className="text-gray-600 text-sm">{c.appearance || "Sem aparência"}</p>
          <div className="flex gap-2 mt-2">
            <button onClick={() => onEdit(c)} className="px-2 py-1 bg-blue-500 text-white rounded">Editar</button>
            <button onClick={() => onDelete(c.id)} className="px-2 py-1 bg-red-500 text-white rounded">Excluir</button>
          </div>
        </div>
      ))}
    </div>
  );
}

function Form({ character, onSave, onCancel }) {
  const [form, setForm] = useState({
    name: character.name || "",
    appearance: character.appearance || "",
    hp: character.hp || 10,
    mp: character.mp || 0,
    str: character.str || 10,
    dex: character.dex || 10,
    int: character.int || 10,
    abilities: character.abilities?.join("\n") || "",
    skills: character.skills?.join("\n") || "",
    items: character.items?.join("\n") || "",
  });

  const update = (field, value) => setForm({ ...form, [field]: value });

  const submit = () => {
    onSave({
      ...character,
      ...form,
      abilities: form.abilities.split("\n").map((s) => s.trim()).filter(Boolean),
      skills: form.skills.split("\n").map((s) => s.trim()).filter(Boolean),
      items: form.items.split("\n").map((s) => s.trim()).filter(Boolean),
    });
  };

  return (
    <div className="border p-4 rounded bg-white shadow">
      <h2 className="text-xl font-semibold mb-3">{character.id ? "Editar" : "Criar"} Personagem</h2>

      <div className="space-y-2">
        <input className="w-full p-2 border rounded" placeholder="Nome" value={form.name} onChange={(e) => update("name", e.target.value)} />
        <textarea className="w-full p-2 border rounded" placeholder="Aparência" value={form.appearance} onChange={(e) => update("appearance", e.target.value)} />

        <div className="grid grid-cols-3 gap-2">
          <input className="p-2 border rounded" type="number" placeholder="HP" value={form.hp} onChange={(e) => update("hp", e.target.value)} />
          <input className="p-2 border rounded" type="number" placeholder="MP" value={form.mp} onChange={(e) => update("mp", e.target.value)} />
          <input className="p-2 border rounded" type="number" placeholder="FOR" value={form.str} onChange={(e) => update("str", e.target.value)} />
          <input className="p-2 border rounded" type="number" placeholder="DES" value={form.dex} onChange={(e) => update("dex", e.target.value)} />
          <input className="p-2 border rounded" type="number" placeholder="INT" value={form.int} onChange={(e) => update("int", e.target.value)} />
        </div>

        <textarea className="w-full p-2 border rounded" placeholder="Habilidades (uma por linha)" value={form.abilities} onChange={(e) => update("abilities", e.target.value)} />
        <textarea className="w-full p-2 border rounded" placeholder="Perícias (uma por linha)" value={form.skills} onChange={(e) => update("skills", e.target.value)} />
        <textarea className="w-full p-2 border rounded" placeholder="Itens (uma por linha)" value={form.items} onChange={(e) => update("items", e.target.value)} />
      </div>

      <div className="flex gap-2 mt-4">
        <button onClick={submit} className="px-4 py-2 bg-green-600 text-white rounded">Salvar</button>
        <button onClick={onCancel} className="px-4 py-2 bg-gray-400 text-white rounded">Cancelar</button>
      </div>
    </div>
  );
}
